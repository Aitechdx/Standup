# Stand & Stretch

A single-file React (UMD + Babel) app that reminds you to stand for 10 minutes, then sit for 50 minutes, repeating until bedtime.

## Run
Open `index.html` in any browser.

## GitHub Pages
1. Create a GitHub repository (e.g., stand-and-stretch)
2. Upload this index.html and README.md to the root of the repository
3. Go to Settings → Pages → Source: Deploy from a branch → Branch: main (root)
4. Your app will be live at https://<your-username>.github.io/stand-and-stretch/
